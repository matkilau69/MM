# gasless-uniswap
swap away without hodling ETH

# Here is the frontend: https://gasless-uniswap.web.app/<br/>
For more detailed explanation : https://medium.com/@shahyashs145/introducing-gasless-uniswap-dd056a2355de<br/>
Demo video: https://www.youtube.com/watch?v=wu5mGoWAMuE

Try it out on ropsten or matic testnetv3 (rpc: https://testnetv3.matic.network)

# Run the front end locally
1. go to src directory
2. npm install
3. npm run dev

# Deploy the contracts
1. npm install
2. truffle migrate --network [networkName]
